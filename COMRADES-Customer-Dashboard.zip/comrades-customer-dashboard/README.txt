COMRADES — Dashboard Pelanggan

Cara menjalankan:
1. Extract folder ZIP.
2. Buka folder comrades-customer-dashboard.
3. Buka index.html menggunakan Chrome, Edge, atau browser lain.

Dashboard menggunakan HTML, CSS, dan JavaScript murni. Tidak memerlukan instalasi atau koneksi internet.

Catatan:
- Palet warna, wordmark, gaya header, dan elemen produk mengikuti file referensi COMRADES.
- Nama akun, riwayat pesanan, harga, dan status mengambil contoh yang terlihat pada file referensi.
- Foto produk diambil dari gambar katalog pada file referensi.
- Filter status dan pencarian pesanan aktif di sisi browser.
